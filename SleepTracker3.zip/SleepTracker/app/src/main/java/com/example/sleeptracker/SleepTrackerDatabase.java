package com.example.sleeptracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class SleepTrackerDatabase extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Sleep.db";
    public static final String TABLE_NAME = "sleeptracker";
    public static final String COLUMN_NAME_SLIIPID = "slp_id";
    public static final String COLUMN_NAME_DATE = "date";
    public static final String COLUMN_NAME_SLEEPSTART = "start";
    public static final String COLUMN_NAME_SLEEPEND = "end";

    public SleepTrackerDatabase(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public int getSleepRows() {
        SQLiteDatabase db = this.getWritableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, TABLE_NAME);
        return numRows;
    }

    public ArrayList<Sleep> getSleeps() {
        ArrayList<Sleep> sleepList = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM sleeptracker ORDER BY slp_id DESC", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            sleepList.add(new Sleep(
                    res.getInt(res.getColumnIndex(COLUMN_NAME_SLIIPID)),
                    res.getString(res.getColumnIndex(COLUMN_NAME_DATE)),
                    res.getString(res.getColumnIndex(COLUMN_NAME_SLEEPSTART)),
                    res.getString(res.getColumnIndex(COLUMN_NAME_SLEEPEND)))
            );
            res.moveToNext();
        }

        return sleepList;
    }

    public boolean newSleep(String start_time, String end_time) {
        Date presentTime_Date = Calendar.getInstance().getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = dateFormat.format(presentTime_Date);

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cvals = new ContentValues();
        cvals.put("date", date);
        cvals.put("start", start_time);
        cvals.put("end", end_time);
        db.insert(TABLE_NAME, null, cvals);
        return true;
    }

    public boolean updateSleep(int sleep_id, String date, String start_time, String end_time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cvals = new ContentValues();
        cvals.put("date", date);
        cvals.put("start", start_time);
        cvals.put("end", end_time);
        db.update(TABLE_NAME, cvals, "slp_id = ? ", new String[] { Integer.toString(sleep_id)} );
        return true;
    }

    public Integer deleteSleep(int sleep_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "slp_id = ?", new String[] { Integer.toString(sleep_id)});
    }

}
