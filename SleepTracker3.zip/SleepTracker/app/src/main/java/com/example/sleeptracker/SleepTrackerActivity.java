package com.example.sleeptracker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


import com.example.sleeptracker.Sleep;
import com.example.sleeptracker.SleepListAdapter;
import com.example.sleeptracker.SleepTrackerDatabase;

public class SleepTrackerActivity extends AppCompatActivity {

    static SleepTrackerDatabase sleep_database;
    static ListView lvSleep;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sleep_tracker);

        lvSleep = findViewById(R.id.lvSleep);


        lvSleep.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(SleepTrackerActivity.this, String.valueOf(position), Toast.LENGTH_SHORT).show();

            }
        });
        updateList();

        Button btnUpdate = findViewById(R.id.btnUpdate);
        Intent intSlpUpdt = new Intent(SleepTrackerActivity.this, SleepTrackerUpdateActivity.class);
        startActivity(intSlpUpdt);
    }

    protected void updateList() {
        ArrayList<Sleep> sleep_list = new ArrayList<>();

        sleep_database = new SleepTrackerDatabase(getApplicationContext());
        sleep_database.newSleep("12:34", "23:45");

        int row_count = sleep_database.getSleepRows();

        Toast.makeText(this, String.valueOf(row_count), Toast.LENGTH_SHORT).show();

        ArrayList<Sleep> sql_sleeps = sleep_database.getSleeps();

        for (Sleep sleep: sql_sleeps) {
            sleep_list.add( new Sleep(sleep.getId(), sleep.getDate(), sleep.getStart(), sleep.getEnd() ));
        }

        SleepListAdapter rla = new SleepListAdapter(this, R.layout.sleep_list_layout, sleep_list);
        try {
            lvSleep.setAdapter(rla);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
