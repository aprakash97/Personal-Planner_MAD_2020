package com.example.sleeptracker;

import android.app.Activity;
import android.content.Context;
// import android.support.annotation.NonNull;
//import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;



public class SleepListAdapter extends ArrayAdapter<Sleep> {

    private Context rlaContext;
    private ArrayList<Sleep> rlaSleeps;
    int rlaResource;

    public SleepListAdapter(Context context, int resource, ArrayList<Sleep> objects) {
        super(context, resource, objects);
        rlaContext = context;
        rlaResource = resource;
        rlaSleeps = objects;
    }

   @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        Sleep sleep = rlaSleeps.get(position);
        LayoutInflater inflater = (LayoutInflater) rlaContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.sleep_list_layout, null);

        TextView tvDistance = v.findViewById(R.id.tvDuration);
        TextView tvTopspeed = v.findViewById(R.id.tvDate);
        TextView tvDuration = v.findViewById(R.id.tvStartTime);
        TextView tvDate = v.findViewById(R.id.tvEndTIme);

        tvDistance.setText(String.valueOf(sleep.getDate() + " km"));
        tvTopspeed.setText(String.valueOf(sleep.getStart() + " km/h"));
        tvDuration.setText(String.valueOf(sleep.getEnd() + " mins"));
        tvDate.setText(String.valueOf(sleep.getId()));

        return v;
    }
}